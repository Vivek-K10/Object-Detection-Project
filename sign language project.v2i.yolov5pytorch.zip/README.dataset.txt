# sign language project > 2025-11-25 12:26pm
https://universe.roboflow.com/vivek-tqj7a/sign-language-project-psgxb

Provided by a Roboflow user
License: CC BY 4.0

